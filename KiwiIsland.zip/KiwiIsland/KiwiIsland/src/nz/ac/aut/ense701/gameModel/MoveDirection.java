package nz.ac.aut.ense701.gameModel;

/**
 * Enumeration class MoveDirection - describes the direction of a move
 * 
 * @author AS
 * @version August 2011
 */
public enum MoveDirection
{
    NORTH, EAST, SOUTH, WEST;
}

